SELECT CategoryName, 
COUNT(*) AS CategoryCount, 
ROUND(AVG(UnitPrice), 2) AS Average_per_units, 
MIN(UnitPrice) AS Min_per_units, 
MAX(UnitPrice) AS Max_per_units, 
SUM(UnitsOnOrder) AS Total_units_on_order
FROM Product INNER JOIN Category on CategoryId = Category.Id
GROUP BY CategoryId
HAVING CategoryCount > 10
ORDER BY CategoryId;