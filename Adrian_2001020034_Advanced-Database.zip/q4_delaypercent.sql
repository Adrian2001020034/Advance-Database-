SELECT CompanyName, round(firstcnt * 100.0 / cnt, 2) AS percent
FROM 
(
SELECT ShipVia, COUNT(*) AS cnt 
FROM 'Order'
GROUP BY ShipVia
) AS totalCnt
INNER JOIN 
(
SELECT ShipVia, COUNT(*) AS firstcnt 
FROM 'Order'
WHERE ShippedDate > RequiredDate 
GROUP BY ShipVia
) AS firstcnt
ON totalCnt.ShipVia = firstcnt.ShipVia
INNER JOIN Shipper on totalCnt.ShipVia = Shipper.Id
ORDER BY percent DESC;
