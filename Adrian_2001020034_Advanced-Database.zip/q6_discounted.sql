SELECT product_name, CompanyName, ContactName
FROM 
(
SELECT product_name, min(OrderDate), CompanyName, ContactName
FROM 
(
 SELECT Id AS pid, ProductName AS product_name 
 FROM Product 
 WHERE Discontinued == 1
) as discontinued
INNER JOIN OrderDetail on ProductId = pid
INNER JOIN 'Order' on 'Order'.Id = OrderDetail.OrderId
INNER JOIN Customer on CustomerId = Customer.Id
GROUP BY pid
)
ORDER BY product_name ASC;
